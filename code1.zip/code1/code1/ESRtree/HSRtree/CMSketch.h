#ifndef _CMSKETCH_H
#define _CMSKETCH_H

//#include "params.h"
//#include "BOBHash32.h"
#include "BOBHash64.h"
//#include "SPA.h"
#include <cstring>
#include <algorithm>
#include<string>
#include<functional>
#include<vector>
#include<set>
#include<map>
using namespace std;
const int theta=3; //frequency in heap to update
class SPA
{
public:
    virtual void insert(uint64 key, int f) = 0;
};

class CMSketch: public SPA
{
private:
    int w=0 ;
    
	int *counters;
    //int counters[100];
    //vector<vector<int>> counters;
	int d=0;
	BOBHash64 * hash[3];
    std::hash<string> s_hash;
    struct words
    {
        string word="";
        int fre=0;
    };
    struct words_cmp
    {
        bool operator () (words n1,words n2)
        {
            return n1.fre>n2.fre;
        }
    };
    
    //set<words,words_cmp> topk_heap;
    
    //int heap_size=0;
    int max_heap_size=4;
    int get_fake_fre(int x)
    {
        if (x%theta==0) return x;
        return ((x/theta + 1)*theta);
    }
    
    
public:
    map<string,int>topk_heap;
    int me=0;
    int dp=0;
    int value_count=0;
    CMSketch(int memory_in_bytes, int dpp)
    {
        w=memory_in_bytes/4;
        me=memory_in_bytes;
        dp=dpp;
        value_count=0;
        counters=new int[memory_in_bytes/4];
        for(int i=0;i<memory_in_bytes/4;i++){
            counters[i]=0;
        }
        d=dpp;
//        memset(counters, 0, sizeof(counters));
        for (int i = 0; i < dpp; i++)
            hash[i] = new BOBHash64(i + 750);
        topk_heap.clear();
    }

    void print_basic_info()
    {
        printf("CM sketch\n");
        printf("\tCounters: %d\n", w);
        printf("\tMemory: %.6lfMB\n", w * 4.0 / 1024 / 1024);
    }


    virtual ~CMSketch()
    {
        for (int i = 0; i < d; i++)
            delete hash[i];
    }

    int * get(){
        return counters;
    }

    void insert(uint64 key, int f)
    {
        for (int i = 0; i < d; i++) {
            int index = (hash[i]->run((const char *)&key, 4)) % w;
            //cout<<index<<endl;
            counters[index] += f;
        }
        ++value_count;
    }
    bool insert_str(string s,int f)
    {
        
        //theta edited
        
        unsigned long long index=s_hash(s);
        insert(index, f);
        bool change=false;
        
        
        map<string,int>::iterator it;
        it=topk_heap.find(s);
        
        if (it!=topk_heap.end())
        {
           // it->second+=f;
            int newfre=this->query_str(it->first);
            if (newfre>it->second)
            {
                change=true;
                it->second=get_fake_fre(newfre);
            }
        }
        else
        {
            
            if (topk_heap.size()<max_heap_size)
            {
                topk_heap[s]=get_fake_fre(query_str(s));
                
            }
            else
            {
                int fr=query_str(s);
                map<string,int>::iterator minitem=topk_heap.begin();
                for (it=topk_heap.begin();it!=topk_heap.end();it++)
                {
                    if (it->second < minitem->second)
                        minitem=it;
                }
                if (fr>minitem->second)
                {
                    
                    topk_heap.erase(minitem);
                    topk_heap[s]=get_fake_fre(fr);
                    change=true;
                }
            }
        }
        
        return change;
    }

	int query(uint64 key)
    {
        int ret = 1 << 30;
        for (int i = 0; i < d; i++) {
            int tmp = (hash[i]->run((const char *)&key, 4)) % w;
            ret = min(ret, counters[tmp]);
        }
        return ret;
    }
    int query_str(string s)
    {
        /*
        map<string,int>::iterator it=topk_heap.find(s);
        if (it!=topk_heap.end())
        {
            return it->second;
        }
        */
        unsigned long long index=s_hash(s);
        return query(index);
        
    }

    int batch_query(uint64 * data, int n) {
        int ret = 0;
        for (int i = 0; i < n; ++i) {
            ret += query(data[i]);
        }
        return ret;
    }

    void build(uint64 * data, int n)
    {
        for (int i = 0; i < n; ++i) {
            insert(data[i], 1);
        }
    }
    static CMSketch * add_sketch(CMSketch *sketch_a,CMSketch *sketch_b,int me,int dp)
    {
        CMSketch * ans=new CMSketch(me,dp);
        for(int i=0;i<me/4;i++){
            ans->counters[i]=sketch_a->counters[i]+sketch_b->counters[i];
        }
        ans->value_count=sketch_a->value_count+sketch_b->value_count;
        
        map<string,int>temp=sketch_a->topk_heap;
        //temp.insert(sketch_b->topk_heap.begin(),sketch_b->topk_heap.end());
        for (auto it:sketch_b->topk_heap)
        {
            temp[it.first]+=it.second;
        }
        struct p_cmp
        {
            bool operator()(const pair<string,int>&a,const pair<string,int>&b)
            {
                return a.second>b.second;
            }
        };
        vector<pair<string,int>> h(temp.begin(),temp.end());
        sort(h.begin(),h.end(),p_cmp());
        int l=0;
        temp.clear();
        for (auto it:h)
        {
            if (++l>sketch_a->max_heap_size)break;
            //temp[it.first]=it.second;
            temp[it.first]=ans->query_str(it.first);
        }
        ans->topk_heap=temp;
        return ans;
    }
    
    
    
    void print_counter()
    {
        for (int i=0;i<w;i++)
            cout<<counters[i]<<" ";
        return;
    }
    CMSketch get_ne_sketch()
    {
        CMSketch *ans=new CMSketch(me,dp);
        for (int i=0;i<w;i++)
            ans->counters[i]=-counters[i];
        ans->value_count=-value_count;
        map<string,int>newheap;
        for (auto it:topk_heap)
            ans->topk_heap[it.first]=-it.second;
        
        return *ans;
    }
};

#endif //_CMSKETCH_H
