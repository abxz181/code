//

//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/3.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#include<iostream>
#include<cstdio>
#include<string>
#include<functional>
#include"CMSketch.h"
#include<vector>


using namespace std;
std::hash<string> str_hash;

class objdoc
{
public:
    objdoc();
    ~objdoc();
    void add_to_cmsketch(CMSketch * );
    void add_to_doc(string);
private:
    vector<string> * doc;
    
    
    
    
};

objdoc::objdoc()
{
    doc=new vector<string>;
    doc->clear();
    
}

void objdoc::add_to_cmsketch(CMSketch * cm)
{
    vector<string>::iterator it;
    for(it=doc->begin();it!=doc->end();it++)
    {
        //int index=str_hash(*it) % 3000000007;
        uint64 index=str_hash(*it);
        cm->insert(index, 1);
    }
    return;
}

void objdoc::add_to_doc(string s)
{
    doc->push_back(s);
    return;
}




