//
//  score.h
//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/6.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#ifndef score_h
#define score_h

#include"CMSketch.h"
#include <iostream>
#include <string>
#include<fstream>
//#include "RTree.h"
using namespace std;
const double lambda=0.5; //in text relevance
const double alpha=0.8;  //a balance of spitial and text
const double beta=0.9;   //a balance of spiital and text in ESR tree



class query_point
{
public:
    query_point(int,int,vector<string>);     //input location and keywords
    double get_doc_relevance(CMSketch * object_doc,CMSketch * all_docs);
    double D_e(int x,int y);
    double D_st(int x,int y, CMSketch* object_doc,CMSketch * all_docs);
    double Mind_st(int x1,int y1,int x2,int y2,CMSketch * node_doc,CMSketch * all_docs);
    double maxd=0;
    static double get_topk_relevance(CMSketch* ska, CMSketch* skb, CMSketch* all_docs);
    ofstream * qout;
    int * counter;
    
private:
    int loc_x,loc_y;    //location of query
    vector<string> word_list;     //keywords of query
    
    
    
    
};

query_point::query_point(int x,int y,vector<string> s)
{
    loc_x=x;
    loc_y=y;
    word_list=s;
    
}


//get P(Q.keywords|O.doc)
double query_point::get_doc_relevance(CMSketch * object_doc,CMSketch * all_docs)
{
    double ans=1;
    vector<string>::iterator it;
    for (it=word_list.begin();it!=word_list.end();it++)
    {
        double temp=0;
        double tf1=double(object_doc->query_str(*it))/double(object_doc->value_count);
        double tf2=double(all_docs->query_str(*it))/double(all_docs->value_count);
        temp=(1-lambda)*tf1+lambda*tf2;
        ans*=temp;
        
        //single score and total score
    }
    
    return ans;
}

double query_point::D_e(int x, int y)
{
    return (sqrt((loc_x-x)*(loc_x-x)+(loc_y-y)*(loc_y-y)));
}


//get Dst,still need to normalize
double query_point::D_st(int x, int y, CMSketch *object_doc, CMSketch *all_docs)
{
    double ans=0;
    double de=D_e(x,y);
    double p_dis=get_doc_relevance(object_doc, all_docs);
    ans=alpha*de/maxd+(1-alpha)*(1-p_dis);
    return ans;
}

double query_point::Mind_st(int x1, int y1, int x2,int y2, CMSketch *node_doc, CMSketch *all_docs)
{
    double minde;
    double mindst;
    //double d=D_e(x1, y1);minde=d;
    //d=D_e(x1,y2);if (d<minde) minde=d;
    //d=D_e(x2,y1);if (d<minde) minde=d;
    //d=D_e(x2,y2);if (d<minde) minde=d;
    double x,y;
    if (loc_x>=x1&&loc_x<=x2)
        x=loc_x;
    else
    {
        if (loc_x<x1) x=x1;
        if (loc_x>x2) x=x2;
    }
    if (loc_y>=y1&&loc_y<=y2)
        y=loc_y;
    else
    {
        if (loc_y<y1) y=y1;
        if (loc_y>y2) y=y2;
    }
    minde=D_e(x,y);
    double p_dis=get_doc_relevance(node_doc, all_docs);
    mindst=alpha*minde/maxd+(1-alpha)*(1-p_dis);
    return mindst;
}

double query_point::get_topk_relevance(CMSketch* ska, CMSketch* skb, CMSketch* all_docs)
{
    double ans1=1,ans2=1;
    map<string,int>::iterator it;
    vector<string> he;
    he.clear();
    for (it=ska->topk_heap.begin();it!=ska->topk_heap.end();it++)
        he.push_back(it->first);
    query_point *temp =new query_point(0,0,he);
    ans1=temp->get_doc_relevance(skb, all_docs);
    delete temp;
    
    he.clear();
    for (it=skb->topk_heap.begin();it!=skb->topk_heap.end();it++)
        he.push_back(it->first);
    temp =new query_point(0,0,he);
    ans2=temp->get_doc_relevance(ska, all_docs);
    delete temp;
    
    return ((ans1+ans2)/2);
    
}


#endif /* score_h */
