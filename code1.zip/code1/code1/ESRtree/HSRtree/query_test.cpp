//
//  query_test.cpp
//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/3.
//  Copyright © 2021 岑杭家. All rights reserved.
//


/*

#include <stdio.h>
#include<iostream>
#include<functional>
#include"CMSketch.h"

using namespace std;


int main()
{
    int n,m;
    cin>>n;
    for (int i=1;i<=n;i++)
    {
        int x,y,k;
        cin>>x>>y>>k;
        
        
    }
    
    
    
    return 0;
}
*/
