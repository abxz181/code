//
//  test_sketch.cpp
//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/2.
//  Copyright © 2021 岑杭家. All rights reserved.
//


#include<cstdio>
#include<iostream>
#include "CMSketch.h"
#include "BOBHash32.h"
#include "SPA.h"
using namespace std;
const long maxn = 100000000;
//  setting

int range = 16;  // range of data items: 2^{range}
int me_cm = 160* 1024;   // memory size of sketches  (B)
const int total_memory_in_bytes =160 * 1024;  //memory size of CF
int a_filter = 32;     // number of items in A-sketch's filter
int me_kb = me_cm / 1024;     // exchange memory to KB
const int filter_memory_percent = 40;  // parameter of CF percent of filter's memory
const int filter_memory_percent_70 = 70;
const int filter_memory_percent_90 = 90;
const int bucket_num = 1;


int main()
{
    CMSketch *cm_sketch=new CMSketch(me_cm,3);
    /*
    int data[35]={34,23,56,23,34,34,75,56,34,34,23,75,56,92,18,12,34,34,56,41,23,56,34,29,34,34,56,56,56,35,36,37,38,34,34};
    int qu[5]={34,37,23,56,18};
    for (int i=0;i<35;i++)
        cm_sketch->insert(data[i], 1);
    for (int i=0;i<5;i++)
        cout<<cm_sketch->query(qu[i])<<endl;
    */
    string str_data[20]={"apple","fuck","fuck","cnm","cnm","cnm","cnm","wtf","cnm","fuck","cnm","wtf","cnm","cnm","cnm","fuck","cao","cnm","cnm","cnm"};
    std::hash<string> tt;
    //string temp="fuck";
    //cout<<tt(temp)<<endl;
    //cm_sketch->insert(tt(temp)%3000000007, 1);
    cout<<endl;
    for (int i=0;i<20;i++)
    {
        u_int32_t in=tt(str_data[i])%3000000007;
        cout<<in<<endl;
        cm_sketch->insert(in, 1);
        
    }
    string q_str[5]={"cnm","fuck","wtf","cao","apple"};
    for (int i=0;i<5;i++)
    {
        u_int32_t in=tt(q_str[i])%3000000007;
        cout<<cm_sketch->query(in)<<endl;
    }
    return 0;
}


