//
//  main.cpp
//  rtree_temp
//
//  Created by 岑杭家 on 2021/7/22.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
