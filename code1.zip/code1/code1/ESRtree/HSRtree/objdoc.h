//
//  objdoc.h
//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/5.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#ifndef objdoc_h
#define objdoc_h
#include <stdio.h>
#include <iostream>

#include <functional>
#include "CMSketch.h"
using namespace std;






class objdoc
{
public:
    objdoc();
    //~objdoc();
    bool add_to_cmsketch(CMSketch * );
    void add_to_doc(string);
    bool have_sketch=false;
    CMSketch *sk=nullptr;
    void load_sketch(CMSketch);
private:
    vector<string> * doc;
    std::hash<string> str_hash;
    
    
    
};

objdoc::objdoc()
{
    doc=new vector<string>;
    doc->clear();
    have_sketch=false;
    
}

bool objdoc::add_to_cmsketch(CMSketch * cm)
{
    //edited
    if (have_sketch)
    {
        CMSketch *ans=CMSketch::add_sketch(sk, cm, cm->me, cm->dp);
        *cm=*ans;
        return false;
    }
    
    
    
    vector<string>::iterator it;
    bool ok=false;
    for(it=doc->begin();it!=doc->end();it++)
    {
        //int index=str_hash(*it) % 3000000007;
        //uint64 index=str_hash(*it);
        //cm->insert(index, 1);
        if(cm->insert_str(*it, 1))
            ok=true;
    }
    return ok;
}

void objdoc::add_to_doc(string s)
{
    doc->push_back(s);
    return;
}

void objdoc::load_sketch(CMSketch outsketch)
{
    sk=new CMSketch(outsketch.me,outsketch.dp);
    *sk=outsketch;
    have_sketch=true;
    return;
}

#endif /* objdoc_h */
