//
//  simple_test.cpp
//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/5.
//  Copyright © 2021 岑杭家. All rights reserved.
//
/*


#include <stdio.h>
//#include "BOBHash64.h"
#include "objdoc.h"
#include "CMSketch.h"
#include <iostream>
using namespace std;
int main()
{
    int n,m;
    //cin>>n;
    n=8;
    int me=40;
    
    CMSketch * sk[8];
    for (int i=0;i<8;i++) sk[i]=new CMSketch(me,3);
    
    for (int i=0;i<n;i++)
    {
        int x,y,k;
        cin>>x>>y>>k;
        //Rect * rec=new Rect(x,y,x,y);
        
        objdoc *o=new objdoc();
        for (int j=1;j<=k;j++)
        {
            string s;
            cin>>s;
            o->add_to_doc(s);
        }
        o->add_to_cmsketch(sk[i]);
        //tree.Insert(rec->min, rec->max, i,o);
        //sk[i]->print_counter();
        //cout<<endl;
    }
    for (int i=0;i<8;i++)
    {
        cout<<sk[i]->query_str("Chinese")<<" "<<sk[i]->query_str("Spanish")<<" "<<sk[i]->query_str("Restaurant")<<" "<<sk[i]->query_str("food")<<endl;
    }
    
    
    
    return 0;
}

*/
