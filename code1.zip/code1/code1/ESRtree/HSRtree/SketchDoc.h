//
//  SketchDoc.h
//  rtree_temp
//
//  Created by 岑杭家 on 2021/7/28.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#ifndef SketchDoc_h
#define SketchDoc_h


#endif /* SketchDoc_h */


#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;

class SketchDoc
{
public:
    
    
    
private:
    
    
protected:
    
    
    
    
    
    
}
