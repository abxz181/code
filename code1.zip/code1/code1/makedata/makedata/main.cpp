//
//  main.cpp
//  makedata
//
//  Created by 岑杭家 on 2021/8/22.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#include <iostream>
#include<fstream>
#include<string>
#include<vector>
#include<map>
#include<cmath>
#include<iomanip>
using namespace std;
std::hash<string> s_hash;
int main()
{
    ifstream findoc;
    findoc.open("data3doc.txt");
    ifstream finloc;
    finloc.open("nycloc.txt");
    ifstream qin;
    qin.open("data3query.txt");
    ofstream fout;
    fout.open("data3_q.txt");
    ofstream qout;
    qout.open("query3_q.txt");
    int te=0;
    while (!finloc.eof())
    {
        if (++te==10375) break;
        int id;
        finloc>>id;
        double x,y;
        finloc>>x>>y;
        double x1=fabs(x*100);
        double y1=fabs(y*100);
        if (x1!=0&&y1!=0)fout<<setprecision(8)<<x1<<','<<setprecision(8)<<y1;
        
        int k;
        findoc>>k>>id;
        map<string,int> calc;
        calc.clear();
        for (int j=1;j<=k;j++)
        {
            string s;
            findoc>>s;
            calc[s]+=1;
        }
        for (auto i:calc)
        {
            if (x1!=0&&y1!=0)fout<<','<<s_hash(i.first)%10000007<<" "<<i.second;
        }
        if (x1!=0&&y1!=0)fout<<endl;
        //cout<<te++<<endl;
    }
    
    
    int k;
    while (qin>>k)
    {
        //if (te++==8) break;
        double x,y; qin>>x>>y;
        qout<<x<<','<<y<<',';
        int l; qin>>l;
        vector<string> wordlist;
        for (int j=1;j<=l;j++)
        {
            string t;
            qin>>t;
            wordlist.push_back(t);
            if (j<l) qout<<s_hash(t)%10000007<<" ";
            else qout<<s_hash(t)%10000007;
        }
        qout<<endl;
    }
    
    
    
    /*
    string s;
    int calc[100000];
    memset(calc,0,sizeof(calc));
    int l=0;
    while (getline(fdoc, s))
    {
        //cout<<s<<endl;
        vector <int> doc;
        int j=0;
        string temp="";
        while (j<s.length())
        {
            if (s[j]!=','&&j!=s.length()-1)
            {
                temp+=s[j++];
                continue;
            }
            if(temp!="")
            {
                int item=atoi(temp.c_str());
                doc.push_back(item);
                temp="";
                j++;
            }
            
        }
        for (int i=1;i<doc.size();i++)
            calc[doc[i]]++;
        ++l;
    }
    
    for (int i=0;i<100000;i++)
    {
        if (calc[i]>0)
        {
            cout<<i<<" "<<calc[i]<<endl;
        }
    }
    cout<<l;
    */
    return 0;
}
