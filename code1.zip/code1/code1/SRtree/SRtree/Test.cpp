//
// Test.cpp
//
// This is a direct port of the C version of the RTree test program.
//

#include <stdio.h>
#include <iostream>
#include "RTree.h"
#include <functional>
#include "CMSketch.h"
#include <fstream>
#include "objdoc.h"
#include "score.h"
#include<ctime>
using namespace std;







struct Rect
{
  Rect()  {}

  Rect(int a_minX, int a_minY, int a_maxX, int a_maxY)
  {
    min[0] = a_minX;
    min[1] = a_minY;

    max[0] = a_maxX;
    max[1] = a_maxY;
  }


  int min[2];
  int max[2];
};
/*
struct Rect rects[] = 
{
  Rect(0, 0, 2, 2), // xmin, ymin, xmax, ymax (for 2 dimensional RTree)
  Rect(5, 5, 7, 7),
  Rect(8, 5, 9, 6),
  Rect(7, 1, 9, 2),
};
*/
struct Rect rects[]=
{
    Rect(1,1,1,1),
    Rect(1,2,1,2),
    Rect(2,1,2,1),
    Rect(2,2,2,2),
    Rect(2,3,2,3),
    Rect(6,6,6,6),
    Rect(6,7,6,7),
    Rect(7,6,7,6),
    Rect(7,7,7,7),
    Rect(8,7,8,7),
};
int nrects = sizeof(rects) / sizeof(rects[0]);

Rect search_rect(6, 4, 10, 6); // search will find above rects that this one overlaps


bool MySearchCallback(int id, void* arg) 
{
  printf("Hit data rect %d\n", id);
  return true; // keep going
}


//old test in template
/*

int main()
{
  RTree<int, int, 2, float> tree;

  int i, nhits;
  printf("nrects = %d\n", nrects);

  for(i=0; i<nrects; i++)
  {
    tree.Insert(rects[i].min, rects[i].max, i); // Note, all values including zero are fine in this version
  }

  nhits = tree.Search(search_rect.min, search_rect.max, MySearchCallback, NULL);

  printf("Search resulted in %d hits\n", nhits);

  // Iterator test 
  int itIndex = 0;
  RTree<int, int, 2, float>::Iterator it;
  for( tree.GetFirst(it); 
       !tree.IsNull(it);
       tree.GetNext(it) )
  {
    int value = tree.GetAt(it);
    
    int boundsMin[2] = {0,0};
    int boundsMax[2] = {0,0};
    it.GetBounds(boundsMin, boundsMax);
    printf("it[%d] %d = (%d,%d,%d,%d)\n", itIndex++, value, boundsMin[0], boundsMin[1], boundsMax[0], boundsMax[1]);
  }
  
  // Iterator test, alternate syntax
  itIndex = 0;
  tree.GetFirst(it);
  while( !it.IsNull() )
  {
    int value = *it;
    ++it;
    printf("it[%d] %d\n", itIndex++, value);
  }

  getchar(); // Wait for keypress on exit so we can read console output

  // Output:
  //
  // nrects = 4
  // Hit data rect 1
  // Hit data rect 2
  // Search resulted in 2 hits
  // it[0] 0 = (0,0,2,2)
  // it[1] 1 = (5,5,7,7)
  // it[2] 2 = (8,5,9,6)
  // it[3] 3 = (7,1,9,2)  
  // it[0] 0
  // it[1] 1
  // it[2] 2
  // it[3] 3
}

*/

//new test for POI query
int main()
{
    RTree<int, int, 2, float> *tree=new RTree<int, int, 2, float>();
    ifstream fin;
    //fin.open("input_data.txt");
    ifstream findoc,finloc;
    
    /*
    findoc.open("doctest");
    finloc.open("loctest");
    ifstream qin("query.txt");
    */
    
    //DATA1 *100, DATA2 and DATA3 *1000.
    
    /*
    findoc.open("nycdoc.txt");
    finloc.open("nycloc.txt");
    ifstream qin("nycquery.txt");
    */
    
    
    findoc.open("data3doc.txt");
    finloc.open("nycloc.txt");
    ifstream qin("data3query.txt");
    
    
    //DATA3 has 10375 objects.
    
   
    /*
     int n,m;
     fin>>n;
     CMSketch *t=new CMSketch(40,3);
     t->insert_str("Chinese", 1);
     for (int i=1;i<=n;i++)
     {
     int x,y,k;
     fin>>x>>y>>k;
     Rect * rec=new Rect(x,y,x,y);
     
     objdoc *o=new objdoc();
     for (int j=1;j<=k;j++)
     {
     string s;
     fin>>s;
     o->add_to_doc(s);
     }
     tree->Insert(rec->min, rec->max, i,o);
     
     }
     */
    int te=0;
   
    while (!finloc.eof())
    {
        if (te++==10375)break;
        //data3
        //te++;
        int id;
        finloc>>id;
        double x,y;
        finloc>>x>>y;
        int x1=abs(int(x*1000));
        int y1=abs(int(y*1000));
        Rect * rec=new Rect(x1,y1,x1,y1);
        int k;
        findoc>>k>>id;
        objdoc *o=new objdoc();
        for (int j=1;j<=k;j++)
        {
            string s;
            findoc>>s;
            o->add_to_doc(s);
        }
        tree->Insert(rec->min, rec->max, id,o);
        delete o;
        //cout<<te<<endl;
    }
    
    

    
    
    //tree->m_root->m_cmsketch->print_counter();
    cout<<endl;
    CMSketch* qu=tree->m_root->m_cmsketch;//    ->m_branch[2].m_child->m_cmsketch;
   
    //cout<<qu->query("Chinese")<<" "<<qu->query("Spanish")<<" "<<qu->query("Restaurant")<<" "<<qu->query("food")<<endl;
    cout<<qu->query_str("1")<<" "<<qu->query_str("2")<<endl;
    
    cout<<qu->value_count<<endl;
    
    /*
    vector<string> wordlist;
    wordlist.push_back("1");
    wordlist.push_back("2");
    query_point * query=new query_point(3380,11750,wordlist);
    tree->lkt_search(query, 10);
    */
    
    
    int k;
    ofstream ou("queryout.txt");
    int *c=new int();
    *c=0;
    
    
    cout<<tree->nodecount<<endl;

    while (qin>>k)
    {
        
        double x,y; qin>>x>>y;
        int l; qin>>l;
        vector<string> wordlist;
        for (int j=1;j<=l;j++)
        {
            string t;
            qin>>t;
            wordlist.push_back(t);
        }
        query_point * query=new query_point(x,y,wordlist);
        query->counter=c;
        query->qout=&ou;
        tree->lkt_search(query, k);
    }

  

  
    
    
    /*
    ifstream fin;
    fin.open("input_data.txt");
    int n,m;
    fin>>n;
    CMSketch *t=new CMSketch(40,3);
    t->insert_str("Chinese", 1);
    for (int i=1;i<=n;i++)
    {
        int x,y,k;
        fin>>x>>y>>k;
        Rect * rec=new Rect(x,y,x,y);
        
        objdoc *o=new objdoc();
        for (int j=1;j<=k;j++)
        {
            string s;
            fin>>s;
            o->add_to_doc(s);
        }
        tree->Insert(rec->min, rec->max, i,o);
        
    }
    tree->m_root->m_cmsketch->print_counter();
    cout<<endl;
    CMSketch* qu=tree->m_root->m_cmsketch;//    ->m_branch[2].m_child->m_cmsketch;
    cout<<qu->query_str("Chinese")<<" "<<qu->query_str("Spanish")<<" "<<qu->query_str("Restaurant")<<" "<<qu->query_str("food")<<endl;
    
  
    vector<string> wordlist;
    wordlist.push_back("Chinese");
    query_point * query=new query_point(3,3,wordlist);
    tree->lkt_search(query, 3);
    */
    //fin.close();
    return 0;
}



