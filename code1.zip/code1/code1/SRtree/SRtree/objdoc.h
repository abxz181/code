//
//  objdoc.h
//  rtree_temp
//
//  Created by 岑杭家 on 2021/8/5.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#ifndef objdoc_h
#define objdoc_h
#include <stdio.h>
#include <iostream>

#include <functional>
#include "CMSketch.h"
using namespace std;






class objdoc
{
public:
    objdoc();
    //~objdoc();
    void add_to_cmsketch(CMSketch * );
    void add_to_doc(string);
private:
    vector<string> * doc;
    std::hash<string> str_hash;
    
    
    
};

objdoc::objdoc()
{
    doc=new vector<string>;
    doc->clear();
    
}

void objdoc::add_to_cmsketch(CMSketch * cm)
{
    vector<string>::iterator it;
    for(it=doc->begin();it!=doc->end();it++)
    {
        //int index=str_hash(*it) % 3000000007;
        //uint64 index=str_hash(*it);
        //cm->insert(index, 1);
        cm->insert_str(*it, 1);
    }
    return;
}

void objdoc::add_to_doc(string s)
{
    doc->push_back(s);
    return;
}

#endif /* objdoc_h */
