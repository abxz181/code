#ifndef _CMSKETCH_H
#define _CMSKETCH_H

//#include "params.h"
//#include "BOBHash32.h"
#include "BOBHash64.h"
//#include "SPA.h"
#include <cstring>
#include <algorithm>
#include<string>
#include<functional>
#include<vector>
using namespace std;
class SPA
{
public:
    virtual void insert(uint64 key, int f) = 0;
};

class CMSketch: public SPA
{
private:
    int w=0 ;
    
	int *counters;
    //int counters[100];
    //vector<vector<int>> counters;
	int d=0;
	BOBHash64 * hash[3];
    std::hash<string> s_hash;
public:
    int me=0;
    int dp=0;
    int value_count=0;
    CMSketch(int memory_in_bytes, int dpp)
    {
        w=memory_in_bytes/4;
        me=memory_in_bytes;
        dp=dpp;
        value_count=0;
        counters=new int[memory_in_bytes/4];
        for(int i=0;i<memory_in_bytes/4;i++){
            counters[i]=0;
        }
        d=dpp;
//        memset(counters, 0, sizeof(counters));
        for (int i = 0; i < dpp; i++)
            hash[i] = new BOBHash64(i + 750);
    }

    void print_basic_info()
    {
        printf("CM sketch\n");
        printf("\tCounters: %d\n", w);
        printf("\tMemory: %.6lfMB\n", w * 4.0 / 1024 / 1024);
    }


    virtual ~CMSketch()
    {
        for (int i = 0; i < d; i++)
            delete hash[i];
    }

    int * get(){
        return counters;
    }

    void insert(uint64 key, int f)
    {
        for (int i = 0; i < d; i++) {
            int index = (hash[i]->run((const char *)&key, 4)) % w;
            //cout<<index<<endl;
            counters[index] += f;
        }
        ++value_count;
    }
    void insert_str(string s,int f)
    {
        unsigned long long index=s_hash(s);
        insert(index, f);
    }

	int query(uint64 key)
    {
        int ret = 1 << 30;
        for (int i = 0; i < d; i++) {
            int tmp = (hash[i]->run((const char *)&key, 4)) % w;
            ret = min(ret, counters[tmp]);
        }
        return ret;
    }
    int query_str(string s)
    {
        unsigned long long index=s_hash(s);
        return query(index);
        
    }

    int batch_query(uint64 * data, int n) {
        int ret = 0;
        for (int i = 0; i < n; ++i) {
            ret += query(data[i]);
        }
        return ret;
    }

    void build(uint64 * data, int n)
    {
        for (int i = 0; i < n; ++i) {
            insert(data[i], 1);
        }
    }
    static CMSketch * add_sketch(CMSketch *sketch_a,CMSketch *sketch_b,int me,int dp)
    {
        CMSketch * ans=new CMSketch(me,dp);
        for(int i=0;i<me/4;i++){
            ans->counters[i]=sketch_a->counters[i]+sketch_b->counters[i];
        }
        ans->value_count=sketch_a->value_count+sketch_b->value_count;
        
        return ans;
    }
    void print_counter()
    {
        for (int i=0;i<w;i++)
            cout<<counters[i]<<" ";
        return;
    }
};

#endif //_CMSKETCH_H
