//
//  full_doc.h
//  rtree_temp_2_full_doc
//
//  Created by 岑杭家 on 2021/9/15.
//  Copyright © 2021 岑杭家. All rights reserved.
//

#ifndef full_doc_h
#define full_doc_h

#include<string>
#include<set>
using namespace std;
class full_doc
{
private:
    multiset <string> doc;
public:
    int value_count;
    void insert(string s,int f)
    {
        for (int i=0;i<f;i++)
        {
            doc.insert(s);
            ++value_count;
        }
    }
    int query(string s)
    {
        return doc.count(s);
    }
    full_doc()
    {
        doc.clear();
        value_count=0;
    }
    
    static full_doc * union_doc(full_doc* a, full_doc* b)
    {
        full_doc * ans=new full_doc();
        multiset<string> :: iterator it;
        for (it=a->doc.begin();it!=a->doc.end();it++) ans->doc.insert(*it);
        for (it=b->doc.begin();it!=b->doc.end();it++) ans->doc.insert(*it);
        ans->value_count=a->value_count+b->value_count;
        return ans;
    }
    
};




#endif /* full_doc_h */
